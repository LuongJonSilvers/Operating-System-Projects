#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <errno.h>
#include <stdbool.h>
#include "mapreduce.h"
#include "hashmap.h"
#include <pthread.h>
pthread_mutex_t lock,lockaddtolist;
struct kv {
    char* key;
    char* value;
    long int thread;

};
// struct KVnode 
// {
//     char* key;
//     struct KVnode* next;
// };

size_t numInArray;
// int KVnodeCount;
// struct KVnode *head = NULL;
// struct KVnode *current = NULL;
int threads;

long int threadArray[3];
struct kv_list {
    struct kv** elements;
    size_t num_elements;
    size_t size;
};

// struct kv_array{
//     struct kv** kv;
//     size_t num_row;
//     size_t num_col;
//     size_t num_elements;
// };
struct kv* Interimarray;
struct kv_list kvl;
size_t kvl_counter;
// char* existing;
//void insert(char* key) 
// {
//      struct KVnode link = (struct node) malloc(sizeof(struct KVnode));
//      link->key = key;
//      link->next = head;
//      head = link;
// }
void init_kv_list(size_t size) {
    kvl.elements = (struct kv**) malloc(size * sizeof(struct kv*));
    kvl.num_elements = 0;
    kvl.size = size;
}
void init_interim_array(size_t size){
     Interimarray = malloc(size * sizeof(struct kv));
    //struct kv* array = malloc(size * sizeof *array);//need to free
}
void add_to_interim_array(struct kv* elt){
    pthread_mutex_lock(&lockaddtolist);
    
    Interimarray[numInArray].key=(char*)malloc(sizeof(char*)); 
    Interimarray[numInArray].value=(char*)malloc(sizeof(char*));
    Interimarray[numInArray].value=elt->value;
    Interimarray[numInArray].key=elt->key;
    numInArray++;
    pthread_mutex_unlock(&lockaddtolist);

}


void add_to_list(struct kv* elt) {
    pthread_mutex_lock(&lockaddtolist);
    if (kvl.num_elements == kvl.size) {
	kvl.size *= 2;
	kvl.elements = realloc(kvl.elements, kvl.size * sizeof(struct kv*));
    }
    
    
    kvl.elements[kvl.num_elements++] = elt;
    pthread_mutex_unlock(&lockaddtolist);
}

char* get_func(char* key, int partition_number) {
    if (kvl_counter == kvl.num_elements) {
	return NULL;
    }
    struct kv *curr_elt = kvl.elements[kvl_counter];
    if (!strcmp(curr_elt->key, key)) {
	kvl_counter++;
    //return NULL; //!! change back 
	return curr_elt->value;
    }
    return NULL;
}

int cmp(const void* a, const void* b) {
    char* str1 = (*(struct kv **)a)->key;
    char* str2 = (*(struct kv **)b)->key;
    return strcmp(str1, str2);
}
// void push(struct KVnode** head_ref, char* new_key)
// {
//     /* allocate node */
//     struct KVnode* new_node =
//             (struct KVnode*) malloc(sizeof(struct KVnode));
 
//     /* put in the key  */
//     new_node->key  = new_key;
 
//     /* link the old list off the new node */
//     new_node->next = (*head_ref);
 
//     /* move the head to point to the new node */
//     (*head_ref)    = new_node;
// }
// bool search(struct KVnode* head,char* key){
//     struct KVnode* current = head;  // Initialize current
//     while (current != NULL)
//     {
//         if (current->key == key)
//             return true;
//         current = current->next;
//     }
//     return false;
// }
// int getCount(struct KVnode* head)
// {
//     int count = 0;  // Initialize count
//     struct KVnode* current = head;  // Initialize current
//     while (current != NULL)
//     {    printf(" %s =>",current->key);
//         count++;
//         current = current->next;
//     }
//     return count;
// }

/**
 * @brief 
 * it needs to take key/value pairs from the many different mappers 
 * and store them in a way that later reducers can access them, given constraints described below. 
 * Designing and implementing this data structure is thus a central challenge of the project.
 * @param key 
 * @param value 
 */
void MR_Emit(char* key, char* value)
{   pthread_mutex_lock(&lock);
//int currThread;
//int match =0;
// if(!search(head,key)){
//     printf("THIS NEW\n");
//         push(&head,key);
//     }
    
    // printf("in Emit: key = %s, value = %s,size=%ld\n",strdup(key),strdup(value),kvl.num_elements);
    struct kv *elt = (struct kv*) malloc(sizeof(struct kv));
    if (elt == NULL) {
	printf("Malloc error! %s\n", strerror(errno));
	exit(1);
    }
    elt->key = strdup(key); //dog
    elt->value = strdup(value); //1
    // for(int i = elt->from; i < elt->to; i++){
    //     elt->key[i] = (elt->value[i]);
    // }}
    //FILE *fp = fopen(file_name, "r");
    //[(dog:10),(dog:14),(dog:3)]
    //     v          v         v
    //(cat:25)    (cat:100)  (cat:10)
    //     v          v         v
    //(bat:25)    (bat:100)  (bat:10)
    //[KEY VALUE,  ,  ,]                            //// 0,     1,    2
    //reducer threads 3 
    //work load of thread 1: dog10 +dog 14+dog 3
    //work load 2 
    //
    printf("I am in Thread ID : %ld\n",pthread_self());
    
   for (int i = 0; i < threads; i++ ) { //for loop to set thread value of each kv element
      if(threadArray[i] == pthread_self()){ //found threadin threadArray
        elt->thread = i;
          break;
      }
      if(threadArray[i]==0){
        threadArray[i]=pthread_self();
        elt->thread = i;
        break;
      }
      
   }


  
  pthread_mutex_unlock(&lock);
}
//     for(int i =0; i<kvl.num_elements;i++){
//         printf("\ncomparing index %d/%ld,kvl=%s <-> key=%s\n",i,kvl.num_elements,kvl.elements[i]->key,elt->key);
//         if((strcmp(kvl.elements[i]->key,elt->key)==0)&&(elt->thread==kvl.elements[i]->thread)){
//         }else{

//         }
//     }


//    for(int i=0;i<kvl.num_elements;i++){
//         printf("\ncomparing index %d/%ld,kvl=%s <-> key=%s\n",i,kvl.num_elements,kvl.elements[i]->key,elt->key);
//         if(strcmp(kvl.elements[i]->key,elt->key)==0){
//             printf("MATCH,kvl=%s <-> key=%s\n",kvl.elements[i]->key,elt->key);
//             int* kvlElementValue;
//             kvlElementValue = (int *) kvl.elements[i]->value;
//             printf("INTEGER Element: %d",*kvlElementValue);
//             (*kvlElementValue)++;
//             kvl.elements[i]->value=(char *)kvlElementValue;
           
//             pthread_mutex_unlock(&lock);
//             return;
//         }
//     }
    
//     add_to_list(elt);
//     pthread_mutex_unlock(&lock);
//     return;
// }


//    for (int i = 0; i < threads; i++ ) {
//       printf("%ld ,",threadArray[i]);
//    }
//struct kv datastruct[threads][];
//    for(int i =0;i<threads;i++){//iterate thru thread array and insert kv_element in correspond thread category
//         if(elt->thread==i){//kv_element is in correct thread
//             for()
//         }else{

//         }
//    }
/**
int count = 0;
while(count != kvl.num_elements){
  
  for(int i =0; i <rows; i++){
       if(array[i][0] == kvl.elements[count]->key){
           for(int j=0; j <cols; j++){
                   if(array[i][j] == NULL){
                       array[i][j] == kvl.elements[count]->value;
                       break;
                   }
               }
           match = 1;
           break;
       }
  }
  if(match == 0){
       for(int i =0; i <rows; i++){
           if(array[i][0] == NULL){
               array[i][0] = kvl.elements[count]->key;
               for(int j =0; j <cols; j++){
                   if(array[i][j] == NULL){
                   array[i][j] = kvl.elements[count]->value;
                   break;
                  }
             }
             break;
       }
   }
  }
  match = 0;
  count++;
  }
    
pthread_mutex_unlock(&lock);
}
**/


//     for(int i=0;i<kvl.num_elements;i++){
//         printf("\ncomparing index %d/%ld,kvl=%s <-> key=%s\n",i,kvl.num_elements,kvl.elements[i]->key,elt->key);
//         if(strcmp(kvl.elements[i]->key,elt->key)==0){
//             printf("MATCH,kvl=%s <-> key=%s\n",kvl.elements[i]->key,elt->key);
//             int* kvlElementValue;
//             kvlElementValue = (int *) kvl.elements[i]->value;
//             printf("INTEGER Element: %d",*kvlElementValue);
//             (*kvlElementValue)++;
//             kvl.elements[i]->value=(char *)kvlElementValue;
           
//             pthread_mutex_unlock(&lock);
//             return;
//         }
//     }
    
//     add_to_list(elt);
//     pthread_mutex_unlock(&lock);
//     return;
// }
void printDataStruct(){
    printf("==============================================\n");
    // for(int i=0;i<kvl.num_elements;i++){
    //     printf("[KEY=%s,Value=%s]\n",kvl.elements[i]->key,kvl.elements[i]->value);
    // }
    for(int i =0; i<numInArray;i++){
        printf("[KEY=%s,Value=%s]\n",Interimarray[i].key,Interimarray[i].value);
    }
    printf("==============================================");
    //qsort(Interimarray, numInArray-1, sizeof(struct kv*), cmp);
    //printf("==============================================");
    for(int i =0; i<numInArray;i++){
        printf("[KEY=%s,Value=%s]\n",Interimarray[i].key,Interimarray[i].value);
    }
    //printf("count of nodes is %d", getCount(head));
    printf("==============================================");
}

unsigned long MR_DefaultHashPartition(char *key, int num_partitions) {
    unsigned long hash = 5381;
    int c;
    while ((c = *key++) != '\0')
        hash = hash * 33 + c;
    return hash % num_partitions;
}
//Taken from GeeksforGeeks
//https://www.geeksforgeeks.org/c-program-find-size-file/
long int findSize(char file_name[])
{
    // opening the file in read mode
    FILE* fp = fopen(file_name, "r");
  
    // checking if the file exist or not
    if (fp == NULL) {
        printf("File Not Found!\n");
        return -1;
    }
  
    fseek(fp, 0L, SEEK_END);
  
    // calculating the size of the file
    long int res = ftell(fp);
  
    // closing the file
    fclose(fp);
  
    return res;
}
//more geeksforgeeks
//https://www.geeksforgeeks.org/c-program-to-sort-an-array-in-ascending-order/
void swap(int* xp, int* yp)
{
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}
void selectionSort(int arr[], int n)
{
    int i, j, min_idx;
 
    // One by one move boundary of unsorted subarray
    for (i = 0; i < n - 1; i++) {
 
        // Find the minimum element in unsorted array
        min_idx = i;
        for (j = i + 1; j < n; j++)
            if (arr[j] < arr[min_idx])
                min_idx = j;
 
        // Swap the found minimum element
        // with the first element
        swap(&arr[min_idx], &arr[i]);
    }
}

/**
 * @
 * 2d array
 * after mapp function
 * four:4
 * four:4
 * four:3
 *   
 * 
 * 
 * 
 * 
 */



/**
 The most important function is MR_Run, which takes the command line parameters of a given program, a pointer to a Map function (type Mapper, called map), 
 the number of mapper threads your library should create (num_mappers), 
 a pointer to a Reduce function (type Reducer, called reduce), 
 the number of reducers (num_reducers), 
 and finally, a pointer to a Partition function (partition, described below).
 **/
void MR_Run(int argc, char *argv[], Mapper map, int num_mappers,
	    Reducer reduce, int num_reducers, Partitioner partition)
{
    for (int i = 0; i < threads; i++ ) {
      threadArray[i] = 0;
     
   }
   
    init_interim_array(1000);
    //init_kv_list(10);
    //init_kv_array(row,col);
    // int i;
    // for (i = 1; i < argc; i++) {
	// (*map)(argv[i]);
    // }
int rt = 0;
    //struct kv kv;
    pthread_t *thread_map;
    

    ///creates correct number of mapper threads
     //Example: ./hashmap file1 file2 file3 searchWord
    //          0           1   2       3(argc-1)
    //argc = 4; num_mappers = 2, iterations= 0...1
    thread_map = (pthread_t *) malloc (num_mappers*sizeof(pthread_t));
    threads = num_mappers;
    if(num_mappers==argc-1){ //map threads = files;one thread per file
        for (int i =0; i<num_mappers;i++){
            //printf("I'm HERE iteration i = %d/%d with File %s\n",i,num_mappers,argv[i+1]);
            rt = pthread_create(&thread_map[i],NULL,(void *)map,(void *)argv[i+1]);
            if(rt!=0){
                printf("Could not make thread %d\n",i);
                exit(EXIT_FAILURE);
            }
        }
    for(int i=0;i<num_mappers;i++)
        pthread_join(thread_map[i],NULL);
        
    }else if(num_mappers<argc-1){//threads less than files need scheduler//
int array[argc-1];
for (int i =0; i<argc-1;i++){
        long int fileBytes = findSize(argv[i+1]);
        array[i] = fileBytes;
        printf("Size of the file is %ld bytes in file %s added to array[%d] w/ value %ld\n", fileBytes,argv[i+1],i,fileBytes);
        printf("%d\n",array[i]);
}
selectionSort(array,argc-1);


  
    for (int i = 0; i < argc-1; i++)
        printf("%d ", array[i]);
    printf("num_mappers=%d;files=%d\n",num_mappers,argc-1);
    for(int j = 0; j<argc-1;j++){
    for (int i =0; i<num_mappers;i++){

    rt = pthread_create(&thread_map[i],NULL,(void *)map,(void *)argv[j+1]);
    
        if(rt!=0){
            printf("Could not make thread %d\n",i);
            exit(EXIT_FAILURE);
        }
        pthread_join(thread_map[i],NULL);
    }

    }

    
    
    
    
    
    
    
    }else{//threads more than files (will have inactive threads)
        printf("1");
    }
printf("HERE\n");   
printDataStruct();

    qsort(kvl.elements, kvl.num_elements, sizeof(struct kv*), cmp);

    // note that in the single-threaded version, we don't really have
    // partitions. We just use a global counter to keep it really simple
    kvl_counter = 0;
    while (kvl_counter < kvl.num_elements) {
	(*reduce)((kvl.elements[kvl_counter])->key, get_func, 0);
    }
}
